export default {
  flights: [],
  metadata: {
    departure: [],
    destination: [],
    travellers: [],
    classType: []
  },
  apiCallInProgress: 0
};
