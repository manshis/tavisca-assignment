import React from "react";

const HotelForm = () => {
  return <div>Hotels</div>;
};

export default HotelForm;
